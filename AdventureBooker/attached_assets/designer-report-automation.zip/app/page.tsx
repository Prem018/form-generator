"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import MedicalExpenseReport from "@/components/medical-expense-report"
import WorkerProgressReport from "@/components/worker-progress-report"
import { medicalExpenseData1, medicalExpenseData2, workerProgressData1, workerProgressData2 } from "@/data/sample-data"
import type { MedicalExpenseData, WorkerProgressData } from "@/types/report-types"
import { PrinterIcon } from "lucide-react"

export default function Home() {
  const [medicalExpenseDataset, setMedicalExpenseDataset] = useState<MedicalExpenseData>(medicalExpenseData1)
  const [workerProgressDataset, setWorkerProgressDataset] = useState<WorkerProgressData>(workerProgressData1)
  const [activeTab, setActiveTab] = useState("medical")

  const handlePrintMedical = () => {
    document.body.classList.add("print-medical-only")
    setTimeout(() => {
      window.print()
      document.body.classList.remove("print-medical-only")
    }, 100)
  }

  const handlePrintWorker = () => {
    document.body.classList.add("print-worker-only")
    setTimeout(() => {
      window.print()
      document.body.classList.remove("print-worker-only")
    }, 100)
  }

  return (
    <main className="min-h-screen p-4 md:p-8 print:p-0 bg-gray-50">
      <div className="max-w-5xl mx-auto">
        <div className="flex justify-between items-center mb-6 print:hidden">
          <h1 className="text-2xl font-bold text-gray-800">Weekly Progress Report Generator</h1>
        </div>

        <Tabs defaultValue="medical" className="print:hidden" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="medical">Medical & Travel Expense</TabsTrigger>
            <TabsTrigger value="worker">Worker Progress Report</TabsTrigger>
          </TabsList>

          <TabsContent value="medical" className="mt-4">
            <div className="mb-4 flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-700">Medical & Travel Expense Request</h2>
              <div className="flex gap-4">
                <div className="flex gap-2">
                  <Button
                    variant={medicalExpenseDataset === medicalExpenseData1 ? "default" : "outline"}
                    onClick={() => setMedicalExpenseDataset(medicalExpenseData1)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Dataset 1
                  </Button>
                  <Button
                    variant={medicalExpenseDataset === medicalExpenseData2 ? "default" : "outline"}
                    onClick={() => setMedicalExpenseDataset(medicalExpenseData2)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Dataset 2
                  </Button>
                </div>
                <Button
                  onClick={handlePrintMedical}
                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                >
                  <PrinterIcon size={16} />
                  Print Medical Report
                </Button>
              </div>
            </div>
            <div className="border rounded-lg p-6 bg-white shadow-md">
              <MedicalExpenseReport data={medicalExpenseDataset} />
            </div>
          </TabsContent>

          <TabsContent value="worker" className="mt-4">
            <div className="mb-4 flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-700">Worker Progress Report</h2>
              <div className="flex gap-4">
                <div className="flex gap-2">
                  <Button
                    variant={workerProgressDataset === workerProgressData1 ? "default" : "outline"}
                    onClick={() => setWorkerProgressDataset(workerProgressData1)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Dataset 1
                  </Button>
                  <Button
                    variant={workerProgressDataset === workerProgressData2 ? "default" : "outline"}
                    onClick={() => setWorkerProgressDataset(workerProgressData2)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Dataset 2
                  </Button>
                </div>
                <Button onClick={handlePrintWorker} className="flex items-center gap-2 bg-green-600 hover:bg-green-700">
                  <PrinterIcon size={16} />
                  Print Worker Report
                </Button>
              </div>
            </div>
            <div className="border rounded-lg p-6 bg-white shadow-md">
              <WorkerProgressReport data={workerProgressDataset} />
            </div>
          </TabsContent>
        </Tabs>

        {/* Print-only content */}
        <div className="hidden print-medical-only:block">
          <MedicalExpenseReport data={medicalExpenseDataset} />
        </div>
        <div className="hidden print-worker-only:block">
          <WorkerProgressReport data={workerProgressDataset} />
        </div>
      </div>
    </main>
  )
}
