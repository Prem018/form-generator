"use client"

import { useState } from "react"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import type { MedicalExpenseData } from "@/types/report-types"
import ReportHeader from "@/components/report-header"
import ReportFooter from "@/components/report-footer"

interface MedicalExpenseReportProps {
  data: MedicalExpenseData
}

export default function MedicalExpenseReport({ data: initialData }: MedicalExpenseReportProps) {
  const [data, setData] = useState(initialData)
  const [privacyChecked, setPrivacyChecked] = useState(false)

  // Replace the current updateData function with this improved version that handles undefined paths properly
  const updateData = (path: string, value: any) => {
    const pathArray = path.split(".")
    setData((prevData) => {
      const newData = JSON.parse(JSON.stringify(prevData))
      let current = newData
      let parent = null
      let lastKey = ""

      // Navigate to the correct location in the object
      for (let i = 0; i < pathArray.length - 1; i++) {
        const key = pathArray[i]
        parent = current

        // Handle array indices
        if (!isNaN(Number(key))) {
          lastKey = key
          if (parent[Number(key)] === undefined) {
            parent[Number(key)] = {}
          }
          current = parent[Number(key)]
        } else {
          lastKey = key
          if (current[key] === undefined) {
            current[key] = {}
          }
          current = current[key]
        }
      }

      // Set the value at the final location
      const finalKey = pathArray[pathArray.length - 1]
      current[finalKey] = value
      return newData
    })
  }

  return (
    <div className="medical-expense-report a4-page">
      <ReportHeader
        title="Medical & Travel Expense Request"
        claimNo={data.claimNo}
        address="333 Broadway"
        city="Winnipeg, MB R3C 4W3"
        phone="(204) 954-4321"
        tollFree="1-855-954-4321"
        website="wcb.mb.ca"
      />

      <div className="report-content mt-6">
        <p className="mb-4">
          {data.requesterName} requested reimbursement for the following medical and/or travel expenses:
        </p>

        {/* Prescription Drugs */}
        {data.prescriptionDrugs.length > 0 && (
          <div className="mb-6">
            <h3 className="font-bold text-lg mb-2 text-center">Prescription Drugs</h3>
            <table className="w-full border-collapse">
              <thead>
                <tr className="border border-gray-300 bg-gray-50">
                  <th className="border border-gray-300 p-2 text-left font-bold">Drug Name</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Prescription Date</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Date Purchased</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Healthcare Provider Name</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Paid Amount</th>
                </tr>
              </thead>
              <tbody>
                {data.prescriptionDrugs.map((drug, index) => (
                  <tr key={index} className="border border-gray-300">
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={drug.name}
                        onChange={(e) => updateData(`prescriptionDrugs.${index}.name`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={drug.prescriptionDate}
                        onChange={(e) => updateData(`prescriptionDrugs.${index}.prescriptionDate`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={drug.purchaseDate}
                        onChange={(e) => updateData(`prescriptionDrugs.${index}.purchaseDate`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={drug.providerName}
                        onChange={(e) => updateData(`prescriptionDrugs.${index}.providerName`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={`$${drug.paidAmount.toFixed(2)}`}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^0-9.]/g, "")
                          updateData(`prescriptionDrugs.${index}.paidAmount`, Number.parseFloat(value) || 0)
                        }}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Over-the-Counter Drugs */}
        {data.otcDrugs.length > 0 && (
          <div className="mb-6">
            <h3 className="font-bold text-lg mb-2 text-center">Over-the-Counter Drugs</h3>
            <table className="w-full border-collapse">
              <thead>
                <tr className="border border-gray-300 bg-gray-50">
                  <th className="border border-gray-300 p-2 text-left font-bold">Drug Name</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Date Purchased</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Paid Amount</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Seller's Name</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Reason for Purchasing</th>
                </tr>
              </thead>
              <tbody>
                {data.otcDrugs.map((drug, index) => (
                  <tr key={index} className="border border-gray-300">
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={drug.name}
                        onChange={(e) => updateData(`otcDrugs.${index}.name`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={drug.purchaseDate}
                        onChange={(e) => updateData(`otcDrugs.${index}.purchaseDate`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={`$${drug.paidAmount.toFixed(2)}`}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^0-9.]/g, "")
                          updateData(`otcDrugs.${index}.paidAmount`, Number.parseFloat(value) || 0)
                        }}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={drug.sellerName}
                        onChange={(e) => updateData(`otcDrugs.${index}.sellerName`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={drug.reason}
                        onChange={(e) => updateData(`otcDrugs.${index}.reason`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Medical Supplies */}
        {data.medicalSupplies.length > 0 && (
          <div className="mb-6">
            <h3 className="font-bold text-lg mb-2 text-center">Bandages, Braces or Other Medical Supplies</h3>
            <table className="w-full border-collapse">
              <thead>
                <tr className="border border-gray-300 bg-gray-50">
                  <th className="border border-gray-300 p-2 text-left font-bold">Item Purchased</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Date Purchased</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Was this Prescribed?</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Healthcare Provider Name</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Paid Amount</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Seller's Name</th>
                </tr>
              </thead>
              <tbody>
                {data.medicalSupplies.map((item, index) => (
                  <tr key={index} className="border border-gray-300">
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.name}
                        onChange={(e) => updateData(`medicalSupplies.${index}.name`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.purchaseDate}
                        onChange={(e) => updateData(`medicalSupplies.${index}.purchaseDate`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <div className="flex items-center justify-center">
                        <Checkbox
                          checked={item.prescribed}
                          onCheckedChange={(checked) => updateData(`medicalSupplies.${index}.prescribed`, !!checked)}
                        />
                      </div>
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.providerName}
                        onChange={(e) => updateData(`medicalSupplies.${index}.providerName`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={`$${item.paidAmount.toFixed(2)}`}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^0-9.]/g, "")
                          updateData(`medicalSupplies.${index}.paidAmount`, Number.parseFloat(value) || 0)
                        }}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.sellerName}
                        onChange={(e) => updateData(`medicalSupplies.${index}.sellerName`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Parking */}
        {data.parking.length > 0 && (
          <div className="mb-6">
            <h3 className="font-bold text-lg mb-2 text-center">Parking for Medical Appointments</h3>
            <table className="w-full border-collapse">
              <thead>
                <tr className="border border-gray-300 bg-gray-50">
                  <th className="border border-gray-300 p-2 text-left font-bold">Appointment Date</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">
                    Address of Healthcare Provider/Medical Facility
                  </th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Paid Amount</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Meter Used?</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Meter Number</th>
                </tr>
              </thead>
              <tbody>
                {data.parking.map((item, index) => (
                  <tr key={index} className="border border-gray-300">
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.date}
                        onChange={(e) => updateData(`parking.${index}.date`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.address}
                        onChange={(e) => updateData(`parking.${index}.address`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={`$${item.paidAmount.toFixed(2)}`}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^0-9.]/g, "")
                          updateData(`parking.${index}.paidAmount`, Number.parseFloat(value) || 0)
                        }}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <div className="flex items-center justify-center">
                        <Checkbox
                          checked={item.meterUsed}
                          onCheckedChange={(checked) => updateData(`parking.${index}.meterUsed`, !!checked)}
                        />
                      </div>
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.meterNumber}
                        onChange={(e) => updateData(`parking.${index}.meterNumber`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Mileage */}
        {data.mileage.length > 0 && (
          <div className="mb-6">
            <h3 className="font-bold text-lg mb-2 text-center">Mileage to Medical Appointments</h3>
            <p className="mb-2 text-sm">
              The WCB will generally reimburse only those transportation costs which are in excess of costs that would
              be incurred by the worker while travelling to and from work.
            </p>
            <table className="w-full border-collapse">
              <thead>
                <tr className="border border-gray-300 bg-gray-50">
                  <th className="border border-gray-300 p-2 text-left font-bold">Appointment Date</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">
                    Address of Healthcare Provider/Medical Facility
                  </th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Address of Workplace</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Number of km (Round Trip)</th>
                </tr>
              </thead>
              <tbody>
                {data.mileage.map((item, index) => (
                  <tr key={index} className="border border-gray-300">
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.date}
                        onChange={(e) => updateData(`mileage.${index}.date`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.facilityAddress}
                        onChange={(e) => updateData(`mileage.${index}.facilityAddress`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.workplaceAddress}
                        onChange={(e) => updateData(`mileage.${index}.workplaceAddress`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={`${item.kilometers} km`}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^0-9]/g, "")
                          updateData(`mileage.${index}.kilometers`, Number.parseInt(value) || 0)
                        }}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Bus or Taxi */}
        {data.busOrTaxi.length > 0 && (
          <div className="mb-6">
            <h3 className="font-bold text-lg mb-2 text-center">Bus or Taxi Fare for Medical Appointments*</h3>
            <p className="mb-2 text-sm">
              *Note: Pre-approval is required from your WCB representative to claim taxi fare(s).
            </p>
            <table className="w-full border-collapse">
              <thead>
                <tr className="border border-gray-300 bg-gray-50">
                  <th className="border border-gray-300 p-2 text-left font-bold">Appointment Date</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Address of Starting Point</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">
                    Address of Healthcare Provider/Medical Facility
                  </th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Bus or Taxi (indicate one)</th>
                  <th className="border border-gray-300 p-2 text-left font-bold">Total Fare Paid</th>
                </tr>
              </thead>
              <tbody>
                {data.busOrTaxi.map((item, index) => (
                  <tr key={index} className="border border-gray-300">
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.date}
                        onChange={(e) => updateData(`busOrTaxi.${index}.date`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.startingAddress}
                        onChange={(e) => updateData(`busOrTaxi.${index}.startingAddress`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.facilityAddress}
                        onChange={(e) => updateData(`busOrTaxi.${index}.facilityAddress`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={item.transportType}
                        onChange={(e) => updateData(`busOrTaxi.${index}.transportType`, e.target.value)}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                    <td className="border border-gray-300 p-2">
                      <Input
                        value={`$${item.fare.toFixed(2)}`}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^0-9.]/g, "")
                          updateData(`busOrTaxi.${index}.fare`, Number.parseFloat(value) || 0)
                        }}
                        className="border-none p-0 h-auto"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Privacy Notice */}
        <div className="mt-8 flex items-start gap-2">
          <Checkbox
            id="privacy-notice"
            checked={privacyChecked}
            onCheckedChange={(checked) => setPrivacyChecked(checked as boolean)}
            className="mt-1"
          />
          <label htmlFor="privacy-notice" className="text-sm">
            I understand that the Privacy Notice applies to the personal information collected in this document.
          </label>
        </div>
      </div>

      <ReportFooter appId={data.appId} submissionDate={data.submissionDate} pageNumber={1} totalPages={2} />
    </div>
  )
}
