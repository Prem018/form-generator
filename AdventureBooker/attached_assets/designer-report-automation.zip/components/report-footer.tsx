interface ReportFooterProps {
  appId: string
  submissionDate: string
  pageNumber: number
  totalPages: number
}

export default function ReportFooter({ appId, submissionDate, pageNumber, totalPages }: ReportFooterProps) {
  return (
    <div className="report-footer mt-8 text-sm text-gray-600 border-t pt-2">
      <div className="flex justify-between">
        <div>
          <p>Worker App ID: {appId}</p>
          <p>Submitted: {submissionDate}</p>
        </div>
        <div>
          <p>
            Page {pageNumber} of {totalPages}
          </p>
        </div>
      </div>
    </div>
  )
}
