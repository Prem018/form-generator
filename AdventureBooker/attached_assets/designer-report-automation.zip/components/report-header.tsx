import Image from "next/image"

interface ReportHeaderProps {
  title: string
  claimNo: string
  address: string
  city: string
  phone: string
  tollFree: string
  website: string
}

export default function ReportHeader({ title, claimNo, address, city, phone, tollFree, website }: ReportHeaderProps) {
  return (
    <div className="report-header">
      <div className="flex justify-between items-start">
        <div className="flex items-start gap-4">
          <div className="logo-container">
            <Image src="/wcb-logo.png" alt="WCB Logo" width={80} height={80} className="object-contain" />
          </div>
          <div>
            <p className="text-sm">{address}</p>
            <p className="text-sm">{city}</p>
            <p className="text-sm">Phone: {phone}</p>
            <p className="text-sm">Toll Free: {tollFree}</p>
            <p className="text-sm">{website}</p>
          </div>
        </div>
        <div className="claim-number">
          <p className="text-sm font-bold">Claim No. {claimNo}</p>
        </div>
      </div>
      <div className="title-container mt-4 mb-2 text-center">
        <h1 className="text-xl font-bold">{title}</h1>
      </div>
    </div>
  )
}
