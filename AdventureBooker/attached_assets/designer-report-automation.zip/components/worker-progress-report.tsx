"use client"

import { useState } from "react"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import type { WorkerProgressData } from "@/types/report-types"
import ReportHeader from "@/components/report-header"
import ReportFooter from "@/components/report-footer"

interface WorkerProgressReportProps {
  data: WorkerProgressData
}

export default function WorkerProgressReport({ data: initialData }: WorkerProgressReportProps) {
  const [data, setData] = useState(initialData)
  const [painLevel, setPainLevel] = useState(initialData.painLevel)
  const [privacyChecked, setPrivacyChecked] = useState(false)
  const [fullyRecovered, setFullyRecovered] = useState(initialData.fullyRecovered)
  const [returnedToWork, setReturnedToWork] = useState(initialData.returnedToWork)
  const [receivingTreatment, setReceivingTreatment] = useState(initialData.receivingTreatment)
  const [takingMedication, setTakingMedication] = useState(initialData.takingMedication)
  const [doingExercises, setDoingExercises] = useState(initialData.doingExercises)
  const [workingStatus, setWorkingStatus] = useState(initialData.workingStatus)

  // Helper function to update data
  const updateData = (field: string, value: any) => {
    setData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  return (
    <div className="worker-progress-report a4-page">
      <ReportHeader
        title="Worker Progress Report"
        claimNo={data.claimNo}
        address="333 Broadway"
        city="Winnipeg, MB R3C 4W3"
        phone="(204) 954-4321"
        tollFree="1-855-954-4321"
        website="wcb.mb.ca"
      />

      <div className="report-content mt-6">
        <div className="mb-6 border border-gray-300 p-4 rounded shadow-sm">
          <h3 className="font-bold text-lg mb-4 text-center">Recovery</h3>
          <p className="mb-2">{data.name} provided the following updates in relation to their claim:</p>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">
              I rate my current pain/discomfort on a scale of 1-10, where 1 is no pain and 10 is severe pain:
            </h4>
            <RadioGroup
              value={painLevel.toString()}
              onValueChange={(value) => {
                setPainLevel(Number.parseInt(value))
                updateData("painLevel", Number.parseInt(value))
              }}
              className="flex flex-wrap gap-4"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((level) => (
                <div key={level} className="flex items-center space-x-2">
                  <RadioGroupItem value={level.toString()} id={`pain-level-${level}`} />
                  <Label htmlFor={`pain-level-${level}`}>{level}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">Select one:</h4>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="not-recovered"
                  checked={!fullyRecovered}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFullyRecovered(false)
                      updateData("fullyRecovered", false)
                    }
                  }}
                />
                <label htmlFor="not-recovered">I have not fully recovered from my workplace injury.</label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="fully-recovered"
                  checked={fullyRecovered}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setFullyRecovered(true)
                      updateData("fullyRecovered", true)
                    }
                  }}
                />
                <label htmlFor="fully-recovered">I have fully recovered from my workplace injury.</label>
              </div>
            </div>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">I have provided the following comments about my recovery:</h4>
            <Textarea
              value={data.recoveryComments}
              onChange={(e) => updateData("recoveryComments", e.target.value)}
              className="w-full border border-gray-300 p-2 rounded"
            />
          </div>
        </div>

        <div className="mb-6 border border-gray-300 p-4 rounded shadow-sm">
          <h3 className="font-bold text-lg mb-4 text-center">Return to Work</h3>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">Select one:</h4>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="not-returned"
                  checked={!returnedToWork}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setReturnedToWork(false)
                      updateData("returnedToWork", false)
                    }
                  }}
                />
                <label htmlFor="not-returned">I have not returned to work</label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="returned"
                  checked={returnedToWork}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setReturnedToWork(true)
                      updateData("returnedToWork", true)
                    }
                  }}
                />
                <label htmlFor="returned">
                  I returned to work on:
                  <Input
                    value={data.returnToWorkDate}
                    onChange={(e) => updateData("returnToWorkDate", e.target.value)}
                    className="ml-2 w-40 inline-block"
                  />
                </label>
              </div>
            </div>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">I am working:</h4>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="full-duties-regular"
                  checked={workingStatus === "Full duties, regular hours"}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setWorkingStatus("Full duties, regular hours")
                      updateData("workingStatus", "Full duties, regular hours")
                    }
                  }}
                />
                <label htmlFor="full-duties-regular">Full duties, regular hours</label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="full-duties-reduced"
                  checked={workingStatus === "Full duties, reduced hours"}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setWorkingStatus("Full duties, reduced hours")
                      updateData("workingStatus", "Full duties, reduced hours")
                    }
                  }}
                />
                <label htmlFor="full-duties-reduced">Full duties, reduced hours</label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="modified-duties-regular"
                  checked={workingStatus === "Modified duties, regular hours"}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setWorkingStatus("Modified duties, regular hours")
                      updateData("workingStatus", "Modified duties, regular hours")
                    }
                  }}
                />
                <label htmlFor="modified-duties-regular">Modified duties, regular hours</label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="modified-duties-reduced"
                  checked={workingStatus === "Modified duties, reduced hours"}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setWorkingStatus("Modified duties, reduced hours")
                      updateData("workingStatus", "Modified duties, reduced hours")
                    }
                  }}
                />
                <label htmlFor="modified-duties-reduced">Modified duties, reduced hours</label>
              </div>
            </div>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">
              I expect to return to work on:
              <Input
                value={data.expectedReturnDate}
                onChange={(e) => updateData("expectedReturnDate", e.target.value)}
                className="ml-2 w-40 inline-block"
              />
            </h4>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">I have the following concerns about returning to work:</h4>
            <Textarea
              value={data.returnConcerns}
              onChange={(e) => updateData("returnConcerns", e.target.value)}
              className="w-full border border-gray-300 p-2 rounded"
            />
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">
              I was most recently in contact with:
              <Input
                value={data.employerContactName}
                onChange={(e) => updateData("employerContactName", e.target.value)}
                className="mx-2 w-40 inline-block"
              />
              on
              <Input
                value={data.employerContactDate}
                onChange={(e) => updateData("employerContactDate", e.target.value)}
                className="ml-2 w-40 inline-block"
              />
            </h4>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">My return to work is going:</h4>
            <Textarea
              value={data.returnProgress}
              onChange={(e) => updateData("returnProgress", e.target.value)}
              className="w-full border border-gray-300 p-2 rounded"
            />
          </div>
        </div>

        <div className="mb-6 border border-gray-300 p-4 rounded shadow-sm">
          <h3 className="font-bold text-lg mb-4 text-center">Medical Treatment</h3>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">Select one:</h4>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="not-receiving-treatment"
                  checked={!receivingTreatment}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setReceivingTreatment(false)
                      updateData("receivingTreatment", false)
                    }
                  }}
                />
                <label htmlFor="not-receiving-treatment">
                  I am not continuing to receive medical treatment for my workplace injury.
                </label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="receiving-treatment"
                  checked={receivingTreatment}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setReceivingTreatment(true)
                      updateData("receivingTreatment", true)
                    }
                  }}
                />
                <label htmlFor="receiving-treatment">
                  I am continuing to receive medical treatment for my workplace injury from:
                  <Input
                    value={data.treatmentProviderType}
                    onChange={(e) => updateData("treatmentProviderType", e.target.value)}
                    className="ml-2 w-40 inline-block"
                  />
                </label>
              </div>
            </div>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">
              My last medical treatment was
              <Input
                value={data.lastTreatmentDate}
                onChange={(e) => updateData("lastTreatmentDate", e.target.value)}
                className="mx-2 w-40 inline-block"
              />
              from
              <Input
                value={data.lastTreatmentProvider}
                onChange={(e) => updateData("lastTreatmentProvider", e.target.value)}
                className="ml-2 w-40 inline-block"
              />
            </h4>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">
              My next medical treatment is
              <Input
                value={data.nextTreatmentDate}
                onChange={(e) => updateData("nextTreatmentDate", e.target.value)}
                className="mx-2 w-40 inline-block"
              />
              from
              <Input
                value={data.nextTreatmentProvider}
                onChange={(e) => updateData("nextTreatmentProvider", e.target.value)}
                className="ml-2 w-40 inline-block"
              />
            </h4>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">
              I am attending a Chiropractor or Physiotherapist
              <Input
                value={data.therapyFrequency}
                onChange={(e) => updateData("therapyFrequency", e.target.value)}
                className="ml-2 w-40 inline-block"
              />
            </h4>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">Select one:</h4>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="not-taking-medication"
                  checked={!takingMedication}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setTakingMedication(false)
                      updateData("takingMedication", false)
                    }
                  }}
                />
                <label htmlFor="not-taking-medication">I am not taking medication for my workplace injury.</label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="taking-medication"
                  checked={takingMedication}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setTakingMedication(true)
                      updateData("takingMedication", true)
                    }
                  }}
                />
                <label htmlFor="taking-medication">
                  I am taking medication for my workplace injury:
                  <Input
                    value={data.medicationName}
                    onChange={(e) => updateData("medicationName", e.target.value)}
                    className="ml-2 w-40 inline-block"
                  />
                </label>
              </div>
            </div>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">Select one:</h4>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="not-doing-exercises"
                  checked={!doingExercises}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setDoingExercises(false)
                      updateData("doingExercises", false)
                    }
                  }}
                />
                <label htmlFor="not-doing-exercises">I am not doing home exercises for my workplace injury.</label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="doing-exercises"
                  checked={doingExercises}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setDoingExercises(true)
                      updateData("doingExercises", true)
                    }
                  }}
                />
                <label htmlFor="doing-exercises">I am doing home exercises for my workplace injury.</label>
              </div>
            </div>
          </div>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">List the exercises you are doing:</h4>
            <Textarea
              value={data.exercisesList}
              onChange={(e) => updateData("exercisesList", e.target.value)}
              className="w-full border border-gray-300 p-2 rounded"
            />
          </div>
        </div>

        <div className="mb-6 border border-gray-300 p-4 rounded shadow-sm">
          <h3 className="font-bold text-lg mb-4 text-center">Other Information</h3>

          <div className="mb-4">
            <h4 className="font-semibold mb-2">
              I would like to provide the following additional information about my claim/injury:
            </h4>
            <Textarea
              value={data.additionalInfo}
              onChange={(e) => updateData("additionalInfo", e.target.value)}
              className="w-full border border-gray-300 p-2 rounded"
            />
          </div>
        </div>

        {/* Certification */}
        <div className="mt-8 border-t pt-4">
          <p className="text-sm mb-4">
            I certify that the information given on this form is true, correct and complete to the best of my knowledge.
            I agree to notify the Workers Compensation Board of Manitoba (WCB) immediately once I return to any form of
            work and/or employment. I understand that it is an offence to knowingly make a false statement to the WCB. I
            also understand that it is an offence to withhold information from WCB which affects my entitlement to
            compensation (e.g., full or partial recovery from injury, ability to return to work, sources of additional
            income, etc.). I understand that refusing to co-operate with, or follow my treatment, may result in the WCB
            reducing or suspending my benefits.
          </p>

          <div className="flex items-start gap-2">
            <Checkbox
              id="privacy-notice-worker"
              checked={privacyChecked}
              onCheckedChange={(checked) => setPrivacyChecked(checked as boolean)}
              className="mt-1"
            />
            <label htmlFor="privacy-notice-worker" className="text-sm">
              I understand that the Privacy Notice applies to the personal information collected in this document.
            </label>
          </div>
        </div>
      </div>

      <ReportFooter appId={data.appId} submissionDate={data.submissionDate} pageNumber={1} totalPages={3} />
    </div>
  )
}
