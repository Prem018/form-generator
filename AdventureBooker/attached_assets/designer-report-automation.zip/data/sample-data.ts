import type { MedicalExpenseData, WorkerProgressData } from "@/types/report-types"

// Medical Expense Report - Dataset 1
export const medicalExpenseData1: MedicalExpenseData = {
  claimNo: "20042047",
  appId: "712041",
  submissionDate: "March 28, 2024 20:43",
  requesterName: "Madeleine Willson",
  prescriptionDrugs: [
    {
      name: "Naproxen",
      prescriptionDate: "February 28, 2024",
      purchaseDate: "February 29, 2024",
      providerName: "Dr. Best",
      paidAmount: 20.0,
    },
  ],
  otcDrugs: [
    {
      name: "Advil",
      purchaseDate: "March 28, 2024",
      paidAmount: 8.0,
      sellerName: "Shoppers Drug Mart",
      reason: "Pain",
    },
  ],
  medicalSupplies: [
    {
      name: "Tensor",
      purchaseDate: "February 28, 2024",
      prescribed: true,
      providerName: "Dr. Best",
      paidAmount: 10.0,
      sellerName: "Shoppers Drug Mart",
    },
  ],
  parking: [
    {
      date: "March 28, 2024",
      address: "333 St Mary Ave, Winnipeg MB R3C 4A5, Canada",
      paidAmount: 10.0,
      meterUsed: true,
      meterNumber: "12245",
    },
  ],
  mileage: [
    {
      date: "March 28, 2024",
      facilityAddress: "HSC, 820 Sherbrook St, Winnipeg MB R3A 1R9, Canada",
      workplaceAddress: "WCB, 333 Broadway, Winnipeg MB R3C 4W3, Canada",
      kilometers: 20,
    },
  ],
  busOrTaxi: [
    {
      date: "March 28, 2024",
      startingAddress: "25 Furby St, Winnipeg MB R3C 2A2, Canada",
      facilityAddress: "HSC Winnipeg Women's Hospital, 665 William Ave, Winnipeg MB R3E 0Z2, Canada",
      transportType: "Bus",
      fare: 3.0,
    },
    {
      date: "March 27, 2024",
      startingAddress: "25 Furby St, Winnipeg MB R3C 2A2, Canada",
      facilityAddress: "440 Edmonton St, Winnipeg MB R3B 2M4, Canada",
      transportType: "Taxi",
      fare: 15.0,
    },
  ],
}

// Medical Expense Report - Dataset 2
export const medicalExpenseData2: MedicalExpenseData = {
  claimNo: "20042048",
  appId: "712042",
  submissionDate: "April 15, 2024 14:22",
  requesterName: "John Smith",
  prescriptionDrugs: [
    {
      name: "Amoxicillin",
      prescriptionDate: "April 10, 2024",
      purchaseDate: "April 10, 2024",
      providerName: "Dr. Johnson",
      paidAmount: 15.5,
    },
    {
      name: "Hydrocodone",
      prescriptionDate: "April 12, 2024",
      purchaseDate: "April 12, 2024",
      providerName: "Dr. Johnson",
      paidAmount: 25.75,
    },
  ],
  otcDrugs: [
    {
      name: "Tylenol",
      purchaseDate: "April 14, 2024",
      paidAmount: 12.99,
      sellerName: "Walmart Pharmacy",
      reason: "Headache",
    },
    {
      name: "Ibuprofen",
      purchaseDate: "April 15, 2024",
      paidAmount: 9.99,
      sellerName: "Safeway Pharmacy",
      reason: "Inflammation",
    },
  ],
  medicalSupplies: [
    {
      name: "Wrist Brace",
      purchaseDate: "April 11, 2024",
      prescribed: true,
      providerName: "Dr. Johnson",
      paidAmount: 35.99,
      sellerName: "Medical Supply Store",
    },
    {
      name: "Ice Pack",
      purchaseDate: "April 13, 2024",
      prescribed: false,
      providerName: "",
      paidAmount: 12.5,
      sellerName: "Walmart",
    },
  ],
  parking: [
    {
      date: "April 10, 2024",
      address: "Health Sciences Centre, 820 Sherbrook St, Winnipeg",
      paidAmount: 8.0,
      meterUsed: true,
      meterNumber: "45678",
    },
    {
      date: "April 12, 2024",
      address: "St. Boniface Hospital, 409 Taché Ave, Winnipeg",
      paidAmount: 12.0,
      meterUsed: false,
      meterNumber: "",
    },
  ],
  mileage: [
    {
      date: "April 10, 2024",
      facilityAddress: "Health Sciences Centre, 820 Sherbrook St, Winnipeg",
      workplaceAddress: "123 Main St, Winnipeg",
      kilometers: 15,
    },
    {
      date: "April 12, 2024",
      facilityAddress: "St. Boniface Hospital, 409 Taché Ave, Winnipeg",
      workplaceAddress: "123 Main St, Winnipeg",
      kilometers: 22,
    },
  ],
  busOrTaxi: [
    {
      date: "April 14, 2024",
      startingAddress: "123 Main St, Winnipeg",
      facilityAddress: "Pan Am Clinic, 75 Poseidon Bay, Winnipeg",
      transportType: "Taxi",
      fare: 18.5,
    },
  ],
}

// Worker Progress Report - Dataset 1
export const workerProgressData1: WorkerProgressData = {
  claimNo: "20042047WP",
  appId: "712041",
  submissionDate: "March 19, 2024 19:21",
  name: "Madeleine Willson",
  painLevel: 7,
  fullyRecovered: false,
  recoveryComments: "Still experiencing significant pain in my lower back when bending or lifting.",
  returnedToWork: false,
  returnToWorkDate: "",
  workingStatus: "",
  expectedReturnDate: "April 15, 2024",
  returnConcerns: "I'm concerned about being able to perform my regular duties due to the pain.",
  employerContactName: "John Manager",
  employerContactDate: "March 15, 2024",
  returnProgress: "Terrible. Testing Testing",
  receivingTreatment: true,
  treatmentProviderType: "Physiotherapist",
  lastTreatmentDate: "March 17, 2024",
  lastTreatmentProvider: "City Physiotherapy",
  nextTreatmentDate: "March 22, 2024",
  nextTreatmentProvider: "City Physiotherapy",
  therapyFrequency: "twice weekly",
  takingMedication: true,
  medicationName: "Naproxen, Tylenol",
  doingExercises: true,
  exercisesList: "Stretching exercises for lower back, core strengthening exercises as recommended by physiotherapist.",
  additionalInfo: "No info Testing Testing",
}

// Worker Progress Report - Dataset 2
export const workerProgressData2: WorkerProgressData = {
  claimNo: "20042048WP",
  appId: "712042",
  submissionDate: "April 15, 2024 14:22",
  name: "John Smith",
  painLevel: 4,
  fullyRecovered: false,
  recoveryComments: "Pain has decreased significantly but still present during certain movements.",
  returnedToWork: true,
  returnToWorkDate: "April 10, 2024",
  workingStatus: "Modified duties, regular hours",
  expectedReturnDate: "May 1, 2024",
  returnConcerns: "Need to avoid heavy lifting which is part of my regular duties.",
  employerContactName: "Sarah Supervisor",
  employerContactDate: "April 12, 2024",
  returnProgress: "Good so far. My employer has been accommodating with modified duties.",
  receivingTreatment: true,
  treatmentProviderType: "Chiropractor",
  lastTreatmentDate: "April 14, 2024",
  lastTreatmentProvider: "Back in Action Chiropractic",
  nextTreatmentDate: "April 21, 2024",
  nextTreatmentProvider: "Back in Action Chiropractic",
  therapyFrequency: "once weekly",
  takingMedication: true,
  medicationName: "Ibuprofen as needed",
  doingExercises: true,
  exercisesList: "Daily stretching routine, walking 30 minutes per day, light resistance training for upper body.",
  additionalInfo: "I've noticed improvement each week and expect to return to full duties by May.",
}
