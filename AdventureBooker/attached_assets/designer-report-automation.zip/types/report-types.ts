// Medical Expense Report Types
export interface PrescriptionDrug {
  name: string
  prescriptionDate: string
  purchaseDate: string
  providerName: string
  paidAmount: number
}

export interface OTCDrug {
  name: string
  purchaseDate: string
  paidAmount: number
  sellerName: string
  reason: string
}

export interface MedicalSupply {
  name: string
  purchaseDate: string
  prescribed: boolean
  providerName: string
  paidAmount: number
  sellerName: string
}

export interface Parking {
  date: string
  address: string
  paidAmount: number
  meterUsed: boolean
  meterNumber: string
}

export interface Mileage {
  date: string
  facilityAddress: string
  workplaceAddress: string
  kilometers: number
}

export interface BusOrTaxi {
  date: string
  startingAddress: string
  facilityAddress: string
  transportType: "Bus" | "Taxi"
  fare: number
}

export interface MedicalExpenseData {
  claimNo: string
  appId: string
  submissionDate: string
  requesterName: string
  prescriptionDrugs: PrescriptionDrug[]
  otcDrugs: OTCDrug[]
  medicalSupplies: MedicalSupply[]
  parking: Parking[]
  mileage: Mileage[]
  busOrTaxi: BusOrTaxi[]
}

// Worker Progress Report Types
export interface WorkerProgressData {
  claimNo: string
  appId: string
  submissionDate: string
  name: string
  painLevel: number
  fullyRecovered: boolean
  recoveryComments: string
  returnedToWork: boolean
  returnToWorkDate: string
  workingStatus: string
  expectedReturnDate: string
  returnConcerns: string
  employerContactName: string
  employerContactDate: string
  returnProgress: string
  receivingTreatment: boolean
  treatmentProviderType: string
  lastTreatmentDate: string
  lastTreatmentProvider: string
  nextTreatmentDate: string
  nextTreatmentProvider: string
  therapyFrequency: string
  takingMedication: boolean
  medicationName: string
  doingExercises: boolean
  exercisesList: string
  additionalInfo: string
}
